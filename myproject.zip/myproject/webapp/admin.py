from django.contrib import admin
from . models import employees

admin.site.register(employees)
